var dropbox = document.getElementById("dropbox");
var fileselect = document.getElementById("fileselect");

dropbox.addEventListener("dragenter", dragOver, false); // entras en esa capa arrastrando algo
dropbox.addEventListener("dragleave", dragOver, false); // sales de esa capa
dropbox.addEventListener("dragover", dragOver, false); // te mueves arrastrando algo en la capa
dropbox.addEventListener("drop", gestorFicheros, false); // sueltas los ficheros

fileselect.addEventListener("change", gestorFicheros, false); // misma funcion para gestionar el evento pero este usando el boton para subir ficheros

function dragOver(evt) {
    // evita que el evento se propague a capas que contienen la capa actual de forma sucesiva
    evt.stopPropagation();
// deshabilitar el comportamiento por defecto
    evt.preventDefault();
// modifica la clase del elemento objetivo del evento, si arrastramos ficheros por encima le aplicamos la clase hover a ese elemento
    evt.target.className = (evt.type == "dragover" ? "hover" : "");
}

function gestorFicheros(e) {
// cancelar evento y cambiar estilo destino
    dragOver(e);
// obtener ficheros (FileList) del input (izquierda) o del drag&drop (derecha)
    var files = e.target.files || e.dataTransfer.files;
// procesar todos los objetos File
    for (var i = 0, f; f = files[i]; i++) {
        parsearFichero(f);
    }
}

function parsearFichero(file) {
    document.getElementById('mensajes').innerHTML +=
        "<p>Datos del fichero: <strong>" + file.name +
        "</strong> Tipo: <strong>" + file.type +
        "</strong> Tamaño: <strong>" + file.size +
        "</strong> Bytes</p>";
}

function validarDatos(){
    var nombre = document.getElementById('nombre');
    var tel = document.getElementById('tel');
    var email = document.getElementById('email');
    var libros = document.getElementById('libros');
    var cantidad = document.getElementById('cantidad');

    // Variable auxliar que indica si ha habido algún error
    var validado = true;

    // Comprobar que el campo del nombre no esté vacío
    if(!nombre.value){
        document.getElementById('errNombre').innerHTML = "El campo del Nombre es obligatorio";
        validado = false;
    } else{
        document.getElementById('errNombre').innerHTML = "";
    }

    // Comprobar que el campo del telefono sea correcto
    const regexTel = '^[0-9]{3}-[0-9]{3}-[0-9]{3}$|^[0-9]{3}[0-9]{3}[0-9]{3}$';
    if(!tel.value.match(regexTel)) {
        document.getElementById('errTel').innerHTML = "El campo del Teléfono debe contener el patrón 123(-)456(-)789";
        validado = false;
    } else{
        document.getElementById('errTel').innerHTML = "";
    }

    // Comprobar que el campo del email sea correcto
    const regexEmail = '^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$';
    if(!email.value.match(regexEmail)) {
        document.getElementById('errEmail').innerHTML = "El campo del Email es incorrecto. Debe tener el siguiente formato: hola@gmail.com";
        validado = false;
    } else{
        document.getElementById('errEmail').innerHTML = "";
    }

    // Comprobar que el campo de los libros no esté vacío
    if(!libros.value){
        document.getElementById('errLibro').innerHTML = "El campo del Libro es obligatorio";
        validado = false;
    } else{
        document.getElementById('errLibro').innerHTML = "";
    }

    // Comprobar que el campo de la cantidad sea un valor entre 1 y 5
    if(cantidad.value < 1 || cantidad.value > 5){
        document.getElementById('errCantidad').innerHTML = "La cantidad debe ser un número del 1 al 5";
        validado = false;
    } else{
        document.getElementById('errCantidad').innerHTML = "";
    }

    if(validado){
        console.log("Los datos se han enviado correctamente");
    }
    // Devolver false para que no se recargue la página y se puedan mostrar los mensajes
    return false;
}



