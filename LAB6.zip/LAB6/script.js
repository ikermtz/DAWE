

window.onload = function(){

    // Coordenadas del rectángulo
    let x = 0;
    let y = 0;

    // Dimensiones del rectángulo
    const ancho = 29;
    const alto = 42;


    // Obtener el canvas donde se dibujará el contenido
    let lienzo = document.getElementById("lienzo");
    let context = lienzo.getContext("2d");

    // Llamar al listener que gestiona el movimiento del rectángulo
    moverse();

    // Cargar la imagen completa en las coordenadas (0,0)
    let logo = new Image();
    logo.onload = function(){
        context.drawImage(logo, 0, 0);

        // Dibujar el rectángulo rojo
        rectangulo();

        // Escribir las coordenadas del rectángulo arriba a la derecha de la pantalla
        context.fillText("(" + x + ","+ y +")", logo.width - 45, 15);
    };
    logo.src = "spritesheet.png";

    // Cargar la imagen pequeña (zoom)
    let logoTxiki = new Image();
    logoTxiki.onload = function(){

        // drawImage(imagen, imgX, imgY, imgAncho, imgAlto, lienzoX, lienzoY, LienzoAncho, LienzoAlto)
        context.drawImage(logoTxiki, x, y, ancho, alto, 500, 0, ancho * 2, alto * 2);
    };
    logoTxiki.src="spritesheet.png";


    // Funcion que pinta el rectángulo rojo
    function rectangulo(){
        context.beginPath();                        // Crear el puntero
        context.moveTo(x,y);                        // Colocar el puntera
        context.lineTo(x + ancho,y);             // Señalar las líneas
        context.lineTo(x + ancho,y + alto);
        context.lineTo(x,y + alto);
        context.closePath();                        // Cerrar puntero
        context.lineWidth = "4";                    // Configurar anchura de los bordes
        context.strokeStyle = "red";                // Configurar color de los bordes
        context.stroke();                           // Dibujar líneas
    }

    // Función que actualiza la vista al pulsar las flechas
    function moverse(){
        document.addEventListener("keydown", function(event){

            // Obtener el nombre de la tecla pulsada
            const keyName = event.key;

            // Variables que indican el desplazamiento del rectángulo
            const difx = ancho / 2;
            const dify = alto / 2;

            // Eliminar vista anterior
            context.clearRect(0, 0, lienzo.width, lienzo.height);

            // Dibujar imagen
            context.drawImage(logo, 0, 0);

            // Actualizar coordenadas del rectángulo en función de la tecla pulsada y su posición actual
            switch(keyName){
                case "ArrowRight":      // Se ha pulsado la derecha
                    if ((x + ancho + difx) <= logo.width){              // No está en el tope
                        x = x + difx;
                    } else{                                             // Está en el tope
                        x = logo.width - ancho;
                    }
                    break;

                case "ArrowLeft":      // Se ha pulsado la izquierda
                    if ((x - difx) >= 0){                               // No está en el tope
                        x = x - difx;
                    } else{                                             // Está en el tope
                        x = 0;
                    }
                    break;

                case "ArrowUp":      // Se ha pulsado arriba
                    if ((y - dify) >= 0){                              // No está en el tope
                        y = y - dify;
                    } else{                                             // Está en el tope
                        y = 0;
                    }
                    break;

                case "ArrowDown":      // Se ha pulsado abajo
                    if ((y + alto + dify) <= logo.height){              // No está en el tope
                        y = y + dify;
                    } else{                                             // Está en el tope
                        y = logo.height - alto;
                    }
                    break;
            }
            // Actualizar el rectángulo en las nuevas coordenadas
            rectangulo();

            // Actualizar imagen pequeña: drawImage(imagen, imgX, imgY, imgAncho, imgAlto, lienzoX, lienzoY, LienzoAncho, LienzoAlto)
            context.drawImage(logoTxiki, x, y, ancho, alto, 500, 0, ancho * 2, alto * 2);

            // Actualizar texto con las coordenadas del rectángulo
            context.fillText("(" + x + ","+ y +")", logo.width - 45, 15);
        });
    }
}