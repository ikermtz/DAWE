
window.onload = function() {
    // Variables globales de utilidad
    var canvas = document.querySelector("canvas");
    var ctx = canvas.getContext("2d");
    var w = canvas.width;
    var h = canvas.height;
// var x = 130,
//  y = 135; // posición inicial de Vaus
    var delta;
    var ANCHURA_LADRILLO = 16,
        ALTURA_LADRILLO = 8;
    var coords = {
        grey: [64,0],
        red: [0,0],
        green: [16,8],
        yellow: [16,0],
        purple: [48,0]
    }

// var frames = 30;

    function intersects(left, up, right, bottom, cx, cy, radius )
    {
        var closestX = (cx < left ? left : (cx > right ? right : cx));
        var closestY = (cy < up ? up : (cy > bottom ? bottom : cy));
        var dx = closestX - cx;
        var dy = closestY - cy;
        var side;

        var dt = Math.abs(up - cy);
        var db = Math.abs(bottom - cy);
        var dr = Math.abs(right - cx);
        var dl = Math.abs(left - cx);
        var dm = Math.min(dt, db, dr, dl);
        switch (dm) {
            case dt:
                side = "top";
                break;
            case db:
                side = "bottom";
                break;
            case dr:
                side = "right";
                break;
            case dl:
                side = "left";
                break;
        }

        return result = { c : ( dx * dx + dy * dy ) <= radius * radius, d : side  };
    }

// Collisions between rectangle and circle
    function circRectsOverlap(x0, y0, w0, h0, cx, cy, r) {
        var testX = cx;
        var testY = cy;

        if (testX < x0)
            testX = x0;
        if (testX > (x0 + w0))
            testX = (x0 + w0);
        if (testY < y0)
            testY = y0;
        if (testY > (y0 + h0))
            testY = (y0 + h0);

        return (((cx - testX) * (cx - testX) + (cy - testY) * (cy - testY)) < r * r);
    }

    function testCollisionWithWalls(ball, w, h) {
        // TU CÓDIGO AQUÍ
        var abajo = false;
        // Comprobar si la bola ha colisionado arriba o abajo
        if(ball.y - ball.diameter/2  <= 0){
            ball.y = ball.diameter/2;
            ball.angle = -ball.angle;

        }
        if(ball.y + ball.diameter/2 >= h){
            abajo = true;
            ball.y = h - ball.diameter/2;
            ball.angle = -ball.angle;
        }

        // Comprobar si la bola ha colisionado con alguna pared
        if(ball.x - ball.diameter/2 <= 0){
            ball.x = ball.diameter/2;
            ball.angle = -ball.angle + Math.PI;
        }
        if(ball.x + ball.diameter/2 >= w){
            ball.x = w - ball.diameter/2;
            ball.angle = -ball.angle + Math.PI;
        }
        return abajo;

    }

    function Brick(x, y, color, vidas) {
        // TU CÓDIGO AQUÍ
        this.x = x;
        this.y = y;
        this.color = color;
        this.vidas = vidas;
        this.sprite = new Sprite('img/sprites.png', coords[color], [ANCHURA_LADRILLO,ALTURA_LADRILLO]);

    }

    Brick.prototype = {
        draw: function(ctx) {
            // TU CÓDIGO AQUÍ
            ctx.save();
            ctx.translate(this.x,this.y);
            this.sprite.render(ctx);
            ctx.restore();
        }
    };


// función auxiliar
    var calcDistanceToMove = function(delta, speed) {
        // TU CÓDIGO AQUÍ
        num_pixeles_frame = (speed * delta) / 1000
        return num_pixeles_frame;

    };


    function Ball(x, y, angle, v, diameter, sticky) {
        // TU CÓDIGO AQUÍ
        this.x = x;
        this.y = y;
        this.angle = angle;
        this.v = v;
        this.diameter = diameter;
        this.sticky = sticky;

        this.draw = function(ctx) {
            // TU CÓDIGO AQUÍ
            ctx.save();
            ctx.beginPath();
            // Dibujar un circulo de radio 6
            ctx.arc(this.x, this.y, this.diameter/2, 0, 2*Math.PI);

            // Pintar el fondo del circulo de verde
            ctx.fillStyle = "green";
            ctx.fill();

            // Asignar grosor del borde
            ctx.lineWidth = 1;
            // Colorear borde de negro
            ctx.strokeStyle = "black";
            ctx.stroke();
            ctx.restore();

        };

        this.move = function(x, y) {
            // TU CÓDIGO AQUÍ
            this.speed = calcDistanceToMove(delta, this.v);

            if(x != undefined){
                this.x = x;
            } else{
                var incX = this.speed * Math.cos(this.angle);
                if(this.x + this.diameter/2 + incX > 0 && this.x - this.diameter/2 + incX < w){
                    this.x = this.x + incX;
                }

            }
            if(x != undefined){
                this.y = y;
            } else{
                var incY = this.speed * Math.sin(this.angle);
                if(this.y + this.diameter/2 + incY > 0 && this.y - this.diameter/2 + incY < h){
                    this.y = this.y + incY;
                }

            }
        };

    }

    function Bonus (bricksLeft) {
        this.initialize = true;
        this.appear = Math.floor(Math.random() * bricksLeft);
        this.type= 'C'; // para este ejemplo, sólo un tipo y marcado a fuego (hard-coded)
        this.x = null; // para este ejemplo, el bonus saldrá de esta posición.

        //En el juego
        this.y = null; // debería salir al azar desde la posición del ladrillo roto más reciente
        this.width= 16; // ancho y alto
        this.height= 8;
        this.speed= 80; // velocidad, puedes trastear para ajustarla a lo que más te guste
        this.sprite= new Sprite('img/sprites.png', [224,0], [16,8], 0.5, [0,1,2,3]);// las coordenadas del bonus verde, su anchura y su altura.
                                                                                    // Queremos una animación lenta (0.5) y usar sólo 4 frames, del 0 al 3.
    };
    Bonus.prototype = {
        draw : function(ctx) {
            ctx.save();
            ctx.translate(this.x,this.y);
            this.sprite.render(ctx); // pintar el bonus en su posición x,y
            ctx.restore();
        },
        move : function() {
            this.sprite.update(delta); // apuntar al nuevo frame de la animación
            this.y += calcDistanceToMove(delta, this.speed); // mover el bonus hacia abajo
        }
    };


// Inits
    window.onload = function init() {
        var game = new GF();
        game.start();
    };


// GAME FRAMEWORK STARTS HERE
    var GF = function() {

        // vars for counting frames/s, used by the measureFPS function
        var frameCount = 0;
        var lastTime;
        var fpsContainer;
        var fps, oldTime = 0;

//  var speed = 300; // px/s
//  var vausWidth = 30,   vausHeight = 10;

        var balls = [];
        var bricks = [];
        var bricksLeft;
        var bonuses = []; // declarar e inicializar a vacío un array de bonus al comienzo de GF
        var deleteBrick;
        var lifes = 3;

        //var angleAnterior = 0;

        // vars for handling inputs
        var inputStates = {};

        // game states
        var gameStates = {
            // TU CÓDIGO AQUÍ
            gameRunning:"gameRunning",
            gameOver:"gameOver"
        };

        var currentGameState = gameStates.gameRunning;    // TU CÓDIGO AQUÍ


        // VAUS en objeto literal
        var paddle = {
            dead: false,
            x: 10,
            y: 100,
            width: 32,
            height: 8,
            speed: 300, // pixels/s
            sticky: false,
            sprite: new Sprite('img/sprites.png', [224,40], [32,8], 16, [0,1])
        };



        var ladrillos = [
            // grey
            {
                x: 20,
                y: 20,
                c: 'grey',
                vidas: 1
            }, {
                x: (20 * 2 + ANCHURA_LADRILLO),
                y: 20,
                c: 'grey',
                vidas: 1
            }, {
                x: 20 * 3 + ANCHURA_LADRILLO * 2,
                y: 20,
                c: 'grey',
                vidas: 1
            }, {
                x: 20 * 4 + ANCHURA_LADRILLO * 3,
                y: 20,
                c: 'grey',
                vidas: 1
            }, {
                x: 20 * 5 + ANCHURA_LADRILLO * 4,
                y: 20,
                c: 'grey',
                vidas: 1
            },
            // red
            {
                x: 20,
                y: 42,
                c: 'red',
                vidas: 3
            }, {
                x: 20 * 2.5 + ANCHURA_LADRILLO,
                y: 42,
                c: 'red',
                vidas: 3
            }, {
                x: 20 * 4 + ANCHURA_LADRILLO * 2,
                y: 42,
                c: 'red',
                vidas: 3
            }, {
                x: 20 * 5 + ANCHURA_LADRILLO * 4,
                y: 42,
                c: 'red',
                vidas: 3
            },
            // green
            {
               x: 20,
               y: 60,
               c:'green',
               vidas: 5
            }, {
                x: 20 * 3 + ANCHURA_LADRILLO * 2,
                y: 60,
                c:'green',
                vidas: 5
            }, {
                 x: 20 * 6.6 + ANCHURA_LADRILLO * 2,
                 y: 60,
                 c:'green',
                 vidas: 5
            }
        ];



        var createBricks = function() {
            // TU CÓDIGO AQUÍ            // Crea el array de ladrillos
            for(var i = 0; i < ladrillos.length; i++){
                var aux = new Brick(ladrillos[i].x,ladrillos[i].y,ladrillos[i].c, ladrillos[i].vidas);
                bricks[i] = aux;
            }
            // TU CÓDIGO AQUÍ
            // actualiza bricksLeft
            bricksLeft = bricks.length;
        }

        var drawBricks = function() {
            // TU CÓDIGO AQUÍ
            for(var i = 0; i < bricks.length; i++){
                bricks[i].draw(ctx);
            }
        };

        var measureFPS = function(newTime) {

            // test for the very first invocation
            if (lastTime === undefined) {
                lastTime = newTime;
                return;
            }

            //calculate the difference between last & current frame
            var diffTime = newTime - lastTime;

            if (diffTime >= 1000) {

                fps = frameCount;
                frameCount = 0;
                lastTime = newTime;
            }

            //and display it in an element we appended to the
            // document in the start() function
            fpsContainer.innerHTML = 'FPS: ' + fps;
            frameCount++;
        };

        // clears the canvas content
        function clearCanvas() {
            ctx.clearRect(0, 0, w, h);
            ctx.fillStyle = terrainPattern;
            ctx.fillRect(0, 0, w, h);
        }


        function testBrickCollision(ball) {
            // TU CÓDIGO AQUÍ
            for(var i = 0; i < bricks.length; i++){
                var aux = bricks[i];
                var collision = intersects(aux.x, aux.y, aux.x + ANCHURA_LADRILLO, aux.y + ALTURA_LADRILLO, ball.x, ball.y, ball.diameter/2);
                if(collision.c){
                    ball.v = ball.v + 10;
                    switch (collision.d){
                        case "top":
                            ball.y = aux.y - ball.diameter/2;
                            ball.angle = -ball.angle;
                            break;
                        case "bottom":
                            ball.y = (aux.y + ALTURA_LADRILLO) + ball.diameter/2;
                            ball.angle = -ball.angle;
                            break;
                        case "right":
                            ball.x = (aux.x + ANCHURA_LADRILLO) + ball.diameter/2;
                            ball.angle = -ball.angle + Math.PI;
                            break;
                        case "left":
                            ball.x = aux.x - ball.diameter/2;
                            ball.angle = -ball.angle + Math.PI;
                            break;

                    }
                    // Edicion vidas de ladrillos


                    if(aux.vidas==1){
                        deleteBrick = bricks.splice(i,1)[0];
                        sound.play('point');
                    } else if (aux.vidas==2){
                        deleteBrick = bricks.splice(i,1)[0];
                        var newBrick = new Brick(aux.x,aux.y,"grey",1);
                        bricks.push(newBrick);
                        drawBricks();
                        //bricks[i].vidas= bricks[i].vidas - 1;
                    } else if (aux.vidas==3){
                        var newBrick = new Brick(aux.x,aux.y,"purple",2);
                        bricks.push(newBrick);
                        drawBricks();
                        //bricks[i].vidas= bricks[i].vidas - 1;
                    } else if (aux.vidas==4){
                        var newBrick = new Brick(aux.x,aux.y,"red",3);
                        bricks.push(newBrick);
                        drawBricks();
                        //bricks[i].vidas= bricks[i].vidas - 1;
                    } else {
                        var newBrick = new Brick(aux.x,aux.y,"yellow",4);
                        bricks.push(newBrick);
                        drawBricks();
                        //bricks[i].vidas= bricks[i].vidas - 1;
                    }

                    // Edicion vidas de ladrillos


                    //deleteBrick = bricks.splice(i,1)[0];
                    //sound.play('point');
                }
            }
            // devuelve el número de ladrillos que quedan
            return bricks.length;
        }



        // Función para pintar la raqueta Vaus
        function drawVaus(x, y) {

            // TU CÓDIGO AQUÍ
            ctx.save();
            //ctx.x = x;
            //ctx.y = y;
            ctx.translate(x,y);
            paddle.sprite.render(ctx);
            ctx.restore();
        }

        function displayLifes() {
            // TU CÓDIGO AQUÍ
            ctx.textBaseline = "top";
            ctx.fillStyle = "red";
            ctx.fillText("Lifes: " + lifes, w - 40,5);

        }

        var updatePaddlePosition = function() {

            paddle.sprite.update(delta);

            var incX = Math.ceil(calcDistanceToMove(delta, paddle.speed));
            // TU CÓDIGO AQUÍ
            if(inputStates.right){	// Derecha
                if(paddle.x + paddle.width + incX <= w){
                    paddle.x = paddle.x + incX;	// Incrementar x
                }
                else{
                    paddle.x = w - paddle.width;	// Pegar al final
                }
            } else if(inputStates.left){    // Izquierda
                if(paddle.x - incX >= 0){
                    paddle.x = paddle.x - incX;	// Decrementar x
                }
                else{
                    paddle.x = 0;	// Pegar al inicio
                }
            }
        }


        function updateBalls() {
            for (var i = balls.length - 1; i >= 0; i--) {
                var ball = balls[i];
                ball.move();

                var die = testCollisionWithWalls(ball, w, h);

                // TU CÓDIGO AQUÍ
                // Nuevo: gestiona la pérdida de una bola usando los atributos de paddle
                if(die){
                    balls.splice(i,1);
                    if(balls.length == 0){
                        lifes = lifes - 1;
                        paddle.dead = true;
                    }
                }

                // NUEVO
                // test if ball collides with any brick
                bricksLeft = testBrickCollision(ball);

                // TU CÓDIGO AQUÍ
                // Test if the paddle collides
                // NUEVO: Gestiona el rebote de la bola con Vaus usando los atributos de paddle
                var tocaVaus = circRectsOverlap(paddle.x, paddle.y, paddle.width, paddle.height, ball.x, ball.y, ball.diameter/2);
                if (tocaVaus) {
                    //angleAnterior = ball.angle;
                    if (inputStates.right) {
                        ball.angle = ball.angle * (ball.angle < 0 ? 0.5 : 1.5);
                    } else if (inputStates.left) {
                        ball.angle = ball.angle * (ball.angle > 0 ? 0.5 : 1.5);
                    }else {
                        ball.angle = -ball.angle;
                    }
                    ball.y = ball.y - ball.diameter/2;
                    sound.play('salir');
                }
                /*if ( Math.abs(ball.angle - angleAnterior) < 0.3){
                    console.log("Diferencia:" + Math.abs(ball.angle - angleAnterior) );
                    ball.angle = ball.angle + 0.4;  // Dar una pequeña inclinación
                    console.log("Nuevo ángulo: " + ball.angle);
                }*/
                ball.draw(ctx);
            }
        }
        function updateBonus() {
            for(var i = 0; i < bonuses.length; i++){
                var auxBonus = bonuses[i];
                if((auxBonus.appear == bricksLeft) && deleteBrick != null){
                    if(auxBonus.initialize){
                        auxBonus.x = deleteBrick.x;
                        auxBonus.y = deleteBrick.y;
                        auxBonus.initialize = false;
                    }
                    auxBonus.move();
                    auxBonus.draw(ctx);
                }

            }
        }

        function timer(currentTime) {
            var aux = currentTime - oldTime;
            oldTime = currentTime;
            return aux;
        }

        function loadAssets(callback) {
            // Cargar sonido asíncronamente usando howler.js
            music = new Howl({
                urls: ['assets/Game_Start.ogg'],    //http://localhost/assets/Game_Start.ogg
                volume: 1,
                onload: function() {
                    sound = new Howl({
                        urls: ['assets/sounds.mp3'],   //http://localhost/assets/sounds.mp3
                        volume: 1,
                        sprite: {
                            point: [0, 700],
                            salir: [1000, 1700],
                            empezar: [3000, 2700]
                        }
                    });
                    callback();
                }
            }); // new Howl
        }


        function inicializarGestorTeclado(currentTime) {
            // TU CÓDIGO AQUÍ
            // Crea un listener para gestionar la pulsación
            // de izquierda, derecha o espacio
            // y actualiza inputStates.left .right o .space
            // el listener será para keydown (pulsar)
            // y otro para keyup
            document.addEventListener("keydown", function(event){

                // Obtener el nombre de la tecla pulsada
                const keyName = event.key;

                switch(keyName){
                    case "ArrowRight": // Derecha
                        inputStates.right = 1;
                        break;

                    case "ArrowLeft":  // Izquierda
                        inputStates.left = 1;
                        break;
                    case " ":  // Espacio
                        inputStates.space = 1;
                        console.log("¡¡Espacio!!");
                        break;
                    case "p":  // P
                        if(inputStates.p == 1){
                            inputStates.p = 0;
                        } else{
                            inputStates.p = 1;
                        }
                        break;
                    case "P":  // P
                        if(inputStates.p == 1){
                            inputStates.p = 0;
                        } else{
                            inputStates.p = 1;
                        }
                        break;
                }
            });
            document.addEventListener("keyup", function(event){

                // Obtener el nombre de la tecla pulsada
                const keyName = event.key;

                switch(keyName){
                    case "ArrowRight": // Derecha
                        inputStates.right = 0;
                        break;

                    case "ArrowLeft":  // Izquierda
                        inputStates.left = 0;
                        break;
                    case " ":  // Espacio
                        inputStates.space = 0;
                        break;
                }
            });
        }

        var mainLoop = function(time) {

             // TU CÓDIGO AQUÍ
            // SI currentGameState = en ejecución --> sigue como antes:
            if(currentGameState == gameStates.gameRunning) {
                //main function, called each frame
                measureFPS(time);

                // number of ms since last frame draw
                delta = timer(time);
                if(!inputStates.p){
                    // Clear the canvas
                    clearCanvas();

                    // TU CÓDIGO AQUÍ
                    // NUEVO
                    // Si se ha perdido una vida, comprobar si quedan más
                    // si no --> Game Over
                    // si quedan más --> sacar una nueva bola (y actualizar el atributo paddle.dead)
                    if (paddle.dead) {
                        if (lifes > 0) {
                            music.play();
                            balls.push(new Ball(10, 70, Math.PI / 3, 100, 6, false));
                            ;
                            //var ball1 = new Ball(10, 70, Math.PI/3, 50, 12, 0);
                            //balls[0] = ball1;
                            paddle.dead = false;
                        } else {
                            currentGameState = gameStates.gameOver;
                        }

                    }

                    // Mover Vaus de izquierda a derecha
                    updatePaddlePosition();

                    updateBalls();

                    // draw Vaus
                    drawVaus(paddle.x, paddle.y);

                    // dibujar ladrillos
                    drawBricks();

                    displayLifes();

                    updateBonus(); // incluir esta llamada dentro del mainLoop
                }
                else{
                    ctx.save();
                    ctx.fillStyle = "white";
                    ctx.font = "20px Arial";
                    ctx.fillText("PAUSE", 70, h/2-10);
                    ctx.restore();
                }
                // call the animation loop every 1/60th of second
                requestAnimationFrame(mainLoop);

                // PERO Si currentGameState = GAME OVER
                // PINTAR la pantalla de negro y escribir GAME OVER
            } else if(currentGameState == gameStates.gameOver){
                ctx.save();
                ctx.beginPath();
                ctx.moveTo(0,0);
                ctx.lineTo(0 + w, 0);
                ctx.lineTo(w, h);
                ctx.lineTo(0, h);
                ctx.closePath();
                ctx.fillStyle = "black";
                ctx.fill();
                ctx.stroke();
                ctx.fillStyle = "white";
                ctx.font = "20px Arial";
                ctx.fillText("GAME OVER", 55, h/2-10);
                ctx.restore();
            }
        };

        function init(){
            loadAssets(callback);
            //startNewGame();
            // comenzar la animación
            //requestAnimationFrame(mainLoop);
        }
        function callback(){
            startNewGame();
            // comenzar la animación
            requestAnimationFrame(mainLoop);
        }

        function initTerrain(){
            terrain = new Sprite('img/sprites.png', [0,81], [24,30]);
            terrainPattern = ctx.createPattern ( terrain.image(), 'repeat') ; // repeat forma un mosaico con el fondo;

            // Esto lo he añadido al clearCanvas
            //ctx.fillStyle = terrainPattern;
            //ctx.fillRect(0,0,w,h);
        }

        function startNewGame(){
            initTerrain();

            music.play();
            balls.push(new Ball(10, 70, Math.PI / 3, 100, 6, false));
            createBricks();
            bonuses.push(new Bonus(bricksLeft)); // incluir esta línea a la función startNewGame()
        }

        var start = function() {
            // capa div para visualizar los fps
            fpsContainer = document.createElement('div');
            document.body.appendChild(fpsContainer);
            inicializarGestorTeclado();
            resources.load(['img/sprites.png']);
            resources.onReady(init);
        };

        //our GameFramework returns a public API visible from outside its scope
        return {
            start: start
        };
    };

    var game = new GF();
    game.start();
}
