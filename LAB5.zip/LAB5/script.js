
function buscarLibro(){
    // Obtener el valor del elemento seleccionado
    var isbn = document.getElementById("ISBN").value;

    // Utilizar el elemento para crear la URL a la que le haremos la petición
    var url = "https://openlibrary.org/api/books?bibkeys=" + isbn + "&jscmd=details&format=json";

    // Obtener el JSON de la respuesta de la petición y guardarlo en una variable para reutilizar la petición
    var libro = fetch(url).then((response) => response.json()).then((bookInfo) => bookInfo[isbn]);

    // Crear auxiliar
    var libro_aux = libro;

    // Obtener los detalles del libro
    var detallesLibro = libro_aux.then((bookInfo) => bookInfo['details']);

    // Obtener el título del libro + añadir la respuesta en el <div id="titulo"></div>
    detallesLibro.then(function(data) {
        if(data['full_title'] == undefined){    // Si no tiene el apartado full title usar title
            titulo = data['title'];
        } else{
            titulo = data['full_title'];
        }
        document.getElementById('titulo').innerHTML = "Titulo: " + titulo;});

    // Obtener el nombre de los autores del libro + añadir la respuesta en el <div id="autor"></div>
    detallesLibro.then((author) => author['authors']).then(function(data) {
        var autores='';
        for(var i = 0; i < data['length']; i++){
            if(data['length'] == (i+1)){    // Si es el último nombre
                autores = autores + data[i]['name'];
            } else{ // Si no es el último nombre
                autores = autores + data[i]['name'] + ", ";
            }
        }
        document.getElementById('autor').innerHTML = "Autores: " + autores;});

    // Obtener la imagen del libro + obtener el tamaño L + añadir la respuesta en el <div id="imagen"></div>
    libro.then((author) => author['thumbnail_url'].replace("-S.jpg", "-L.jpg")).then(function(data) {
        document.getElementById('imagen').innerHTML = '<img src="'+data+'">';});
}