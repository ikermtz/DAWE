/* postits.js
 *
 */

// Variable global que almacena el espacio utilizado (en bits) en el localStorage
var espacio = 0;

window.onload = init;

function init() {
	var add_button = document.getElementById("add_button");
	add_button.onclick = createSticky;

	var remove_button = document.getElementById("remove_button");
	remove_button.onclick = clearStickyNotes;

	// cargar las notas postit de localStorage  
	// cada nota se guarda como un par así: postit_X = texto_de_la_nota
	// donde X es el número de la nota
	// por cada una de ellas, llamar al método
	// addStickyToDOM(texto_de_la_nota);
	for(var i = 0; i < localStorage.length; i++){
		var sticky = localStorage.getItem("postit_" + i);
		addStickyToDOM(sticky);
	}
	// Imprimir mensaje con el espacio utilizado en KB
	var espacioText = document.getElementById("memory_space");
	espacioText.innerHTML = "Espacio utilizado: " + (espacio / 8000) + " KB";
}

function createSticky() {
	var value = document.getElementById("note_text").value;
	
	// crear la nota con nombre postit_X, donde X es un número entero
	// (postit_1, postit_2, ...)  y guardarla en el localStorage
	var id = "postit_" + localStorage.length;
	localStorage[id] = value;
	
	addStickyToDOM(value);

	// Imprimir mensaje con el espacio utilizado en KB
	var espacioText = document.getElementById("memory_space");
	espacioText.innerHTML = "Espacio utilizado: " + (espacio / 8000) + " KB";
}


function addStickyToDOM(value) {
	var stickies = document.getElementById("stickies");
	var postit = document.createElement("li");
	var span = document.createElement("span");
	span.setAttribute("class", "postit");
	span.innerHTML = value;
	postit.appendChild(span);
	stickies.appendChild(postit);

	// Calcular el  espacio que ocupa el nuevo post-it (en bits)
	espacio += (value.length * 16);
}

function clearStickyNotes() {
	// Crear un nuevo botón en la ventana de postit notes que al pulsarlo,
	// elimine las notas de pantalla y de localStorage
	// Algoritmo:	
	// obtener una referencia a la capa "stickies"
	// recorrer los hijos (childNodes) de esa referencia,
	// eliminándolos uno a uno (removeChild)

	// Eliminar las notas de la pantalla
	var stickies = document.getElementById("stickies");
	while(stickies.hasChildNodes()){
		var child = stickies.childNodes.item(0);
		stickies.removeChild(child);
	}

	// Eliminar las notas de la pantalla
	localStorage.clear();

	// Inicializar cuenta de espacio en localStorage
	espacio = 0;

	// Imprimir mensaje con el espacio utilizado en KB
	var espacioText = document.getElementById("memory_space");
	espacioText.innerHTML = "Espacio utilizado: " + (espacio / 8000) + " KB";
}
